TINY ARTIST — Android Studio project

An original, offline-first toddler drawing app inspired by common kids' drawing-app features. It does not use Bimi Boo's code, branding, or proprietary art.

Included modes:
- Coloring pages with tap-to-fill regions
- Free drawing with color palette, brush size and eraser
- Trace & Learn practice paths
- Sticker scenes with draggable stickers
- Connect the Dots activity
- Save/export pictures and a local gallery
- Sound toggle and spoken encouragement where supported by the device/browser engine

BUILD AN APK
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose Open and select the TinyArtistAndroid folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35 and the Android Gradle Plugin dependencies.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location (usually app/build/outputs/apk/debug/app-debug.apk).

This environment did not have Android SDK/Gradle installed, so this is source code, not a compiled APK. No network permission, ads, or subscription code is included. The UI and simple vector drawings are original starter content; expand the artwork library for a production release.
